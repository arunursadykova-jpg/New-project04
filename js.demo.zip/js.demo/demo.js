const submit=document.getElementById("submit")

form.addEventListener("submit",()=>{
    resul.textContent="Form Submitted"
});

const btn=document.querySelector("btn")

button.addEventListener("click",()=>{
});




